#include "STM32FDiscovery.h"
#include <stdio.h>
#include <math.h>


#define H 32 //Number of harmonics
#define F 200 // Sampling frequency
#define T 1/F // sampled period
#define PI 3.14
#define A 5.0 //amplitude

unsigned char rec, adc_val;
unsigned int tim2tick = 0;
int count = 0;

char buf[346];
int len;
void sendStr(char buf[], int max);

float polynomial[F];
void clk(void)
{
	RCC_CR = 0;
	RCC_PLLCFGR = 0;
	RCC_CFGR = 0;
		
	RCC_CR |= (1<<16); // HSE set
	while( (RCC_CR & ( 1<<17) ) == 0 ); // wait until HSE ready
	
	RCC_PLLCFGR |= 8;//0x00000008; // set PLLM
	RCC_PLLCFGR |= (336<<6);//|= (336<<6); // 		set PLLN
	RCC_PLLCFGR |= (0<<16); // set PLLP
	RCC_PLLCFGR |= (7<<24);//0x07000000; // set PLLQ

	RCC_PLLCFGR |= (1<<22); // set PLL src HSE
	

	RCC_CR |= (1<<24); // PLL ON
	while( (RCC_CR & (1<<25)) == 0); // wait until PLL ready
	
	FLASH_ACR |= 5;
	RCC_CFGR |= 2; // set PLL to system clock
	
		
	while( (RCC_CFGR & (12) ) != 8); // wait until PLL ready
	
	RCC_CFGR |= (1<<12) | (1<<10); // set APB1 div 4
	RCC_CFGR |= (1<<15); // set APB2 div2	
    SCB_CPACR|= (3<<20)|(3<<22);
}

void set_usart2(){
    //USART PA2, PA3 
    RCC_AHB1ENR |= 1<<0; // PORT CLOCK 
    GPIOA_MODER |=(1<<5) | (1<<7); // alternate function using
    GPIOA_AFRL  |=(7<<8) | (7<<12); //AF7 USING 
   
    //seg USART2
    RCC_APB1ENR |=(1<<17); // UART2 CLK ENABLE 
    USART2_CR1  |=(0<<12); //
    USART2_CR2  |=(0<<13) | (0<<12);

    USART2_BRR  = (unsigned int)(42000000/115200); //115200 = baud rate

    USART2_CR1  |= (1<<3) | (1<<2); // TX RX ENABLE
    USART2_CR1  |= (1<<5); // Using flag to catch interrupt
    USART2_CR1  |= (1<<13); // USART ENABLE

    //USART interrupt enable
    NVIC_ISER1  |= 1<<6; //
}

// ADC1, channel 1, PA1
void set_adc1(){
    RCC_AHB1ENR |= 0x00000001; // RCC clock enable
    GPIOA_MODER |= 3<<2;       // PA1 analog mode
    RCC_APB2ENR |= 1<<8;       // ADC clock enable
    RCC_CFGR    |= 1<<15 | 1<<13; // Seg APB2 div4 = 42MHz

    ADC1_CR2    |= 1<<0; // ADC1 enable
    
    ADC1_SMPR2  |= 3<<0; // channel 1 sammpling cycle 56 cycle
    ADC1_CR1    |= 2<<24 | 1<<5; // 8 bit resolution , quant - divide 8bit
                                 // end-of-conversion interrupt enable
    ADC1_CCR    |= 1<<16;       // PCLK2 div4
    ADC1_SQR1   |= 0<<20;       // channel 1 : 1 conversion
    ADC1_SQR3   |= 1<<0;        // 1st conversion : channeel 1
    
    NVIC_ISER0  |= 1<<18;       // enable interrupt

}

void set_timer2(){

    RCC_APB1ENR |= 1<<0;
    TIM2_CR1     = 0;   // initialize

    TIM2_PSC     = 84-1; // prescaler
    TIM2_ARR     = 1000-1; //Auto reload register
    TIM2_DIER   |= 1<<0;
    TIM2_EGR    |= 1<<0; //
    TIM2_CR1    |= 1<<0; // timer start

    NVIC_ISER0  |= 1<<28;   //enalbe interrupt

}
void USART2_IRQHandler(){
    if(USART2_SR & (1<<5)){ //Interrupt check
        rec = USART2_DR;
        
         
        while( !(USART2_SR & (1<<7)) ); // usart2_sr resigter 6,7 bit is 
        while( !(USART2_SR & (1<<6)) ); // checking process
       
        //GPIOD_ODR ^= 1<<12;

        USART2_CR1 |=(1<<5); //interrupt reset
    }}

void EXTI0_IRQHandler()  {
    GPIOD_ODR ^= 1 << 13;
    GPIOD_ODR ^= 1 << 14;
    GPIOD_ODR ^= 1 << 15;
    
    EXTI_PR |= 1<<0; //clear pending bit for EXTI0
}
uint8_t d_count = 0;
void ADC1_IRQHandler() {
    
    if(d_count != 200){
        if( ADC1_SR & 1<<1 ) {//
            adc_val = ADC1_DR & 0xFF;
        
            while(d_count<F){
               polynomial[d_count] = adc_val;
                d_count++;
            }
       //len = sprintf(buf, "%3d\n", adc_val);
       //sendStr(buf, len);
        }
    }else if(d_count == 200){

    // fourier analysis
    for(int j=0;j<H;j++){
        float freq_component = 0;
        int probe_freq = j;
        for( int i=0; i<F; i++){    //FFT Sum
            float probe = (float)(A)*sin(2*PI*probe_freq*T*i);
            freq_component += polynomial[i]*probe;
           
        }
       
      
       USART2_DR = freq_component;
       //len = sprintf(buf, "%.1f\n", freq_component);
       //sendStr(buf, len);
    }

    d_count = 0;
    }
   // ADC1_CR2    |= 1<<30; //interrupt reset
}
void TIM2_IRQHander(){
    TIM2_SR &= 0X00000000; // flag clear
        
        ADC1_CR2    |= 1<<30; // ADC interrupt reset
            

  
    

}
int main (void)
{
	
	clk();
	
	RCC_CFGR |= 0x04600000;

    /* PORT A */
	RCC_AHB1ENR  |= 1<<0; //RCC clock enable register	
    GPIOA_MODER  |= 0<<0; // input mode
    GPIOA_OTYPER |= 0<<0; // output push-pull
    GPIOA_PUPDR  |= 0<<0; // no pull-up, pull-down
	
	/*button intr set*/
    SYSCFG_EXTICR1 |= 0<<0; // EXTI0 connect to PA0
    EXTI_IMR       |= 1<<0; // Mask EXTI0
    EXTI_RTSR      |= 1<<0; // rising edge trigger enable
    EXTI_FTSR      |= 0<<0; // falling edge trigger disable
    NVIC_ISER0     |= 1<<6; // enable EXTI0 Interrupt
    
    
    /* PORT D */
	RCC_AHB1ENR  |= 1<<3;		// PORTD enable
	GPIOD_MODER  |= 1<<24;		// PORTD 12 general output mode
	GPIOD_MODER  |= 1<<26;		// PORTD 13 general output mode
	GPIOD_MODER  |= 1<<28;		// PORTD 14 general output mode
	GPIOD_MODER  |= 1<<30;		// PORTD 15 general output mode
	GPIOD_OTYPER |= 0x00000000;
	GPIOD_PUPDR	 |= 0x00000000;
	
	//GPIOD_ODR |= 1<<12;

    set_timer2();
    set_adc1();
    set_usart2();
    

    ADC1_CR2 |= 1<<30;
	while(1) {
        if( GPIOA_IDR & 0x00000001 ) {
          //  GPIOD_ODR ^= 1 << 13;
          //  GPIOD_ODR ^= 1 << 14;
          //  GPIOD_ODR ^= 1 << 15;
        }
	}
}
void sendStr(char buf[], int max){
    int cnt = 0;

    while(cnt < max){
        USART2_DR = buf[cnt++]; // echo 1byte 
        while( !(USART2_SR & (1<<7)) ); // check 
        while( !(USART2_SR & (1<<6)) ); // check
    }
}

